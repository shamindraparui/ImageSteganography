﻿Imports System.IO
Imports System.Drawing.Imaging

Public Class encode
    Public Shared final_msg As String
    Public Shared file_name As String
    Public Shared filecontainer() As Byte
    Public Shared datasize As Integer
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        OpenFileDialog2.FileName = ""
        OpenFileDialog2.Filter = "All files (*.*)|*.*"
        OpenFileDialog2.ShowDialog()
        Dim filepath As String
        filepath = OpenFileDialog2.FileName
        Dim file_info As FileInfo = New FileInfo(filepath)
        file_name = file_info.Name
        If file_info.Length < datasize * 1024 Then
            TextBox2.Text = OpenFileDialog2.FileName
            filecontainer = File.ReadAllBytes(filepath)
            Button3.Enabled = True
        Else
            MsgBox("The file is too large to fit in the image. Use a larger image.")
        End If

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Filter = "Image Files(*.bmp;*.jpg;*.jpeg;*.gif;*.png;*tiff)|*.bmp;*.jpg;*.jpeg;*.gif;*.png;*tiff|All files (*.*)|*.*"
        OpenFileDialog1.ShowDialog()
        TextBox1.Text = OpenFileDialog1.FileName
        PictureBox1.Image = Image.FromStream(OpenFileDialog1.OpenFile)
        datasize = (PictureBox1.Image.Width * (PictureBox1.Image.Height - 1)) * 2
        datasize = (datasize / 8) / 1024
        Label2.Text = String.Concat(datasize, "kb")

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim original, copied As Bitmap
        original = PictureBox1.Image

        '******create a blank bmp structure*******
        copied = New Bitmap(original.Width, original.Height, PixelFormat.Format32bppArgb)
        Dim x_coordinate, y_coordinate As Integer
        Dim pxl As Color


        '******** encoding password ********
        x_coordinate = 0
        y_coordinate = 0
        Dim password As String
        lock.ShowDialog()
        password = Trim(lock.TextBox2.Text)
        If password = "" Then
            Me.Close()
        End If
        pxl = original.GetPixel(x_coordinate, y_coordinate)
        pxl = Color.FromArgb(password.Length, pxl.R, pxl.G, pxl.B)
        copied.SetPixel(x_coordinate, y_coordinate, pxl)
        If x_coordinate < original.Width - 1 Then
            x_coordinate = x_coordinate + 1
        Else
            y_coordinate = y_coordinate + 1
            x_coordinate = 0
        End If
        For i = 0 To password.Length - 1 Step 1
            pxl = original.GetPixel(x_coordinate, y_coordinate)
            pxl = Color.FromArgb(Asc(password(i)), pxl.R, pxl.G, pxl.B)
            copied.SetPixel(x_coordinate, y_coordinate, pxl)
            If x_coordinate < original.Width - 1 Then
                x_coordinate = x_coordinate + 1
            Else
                y_coordinate = y_coordinate + 1
                x_coordinate = 0
            End If
        Next


        'encoding file length'
        x_coordinate = 0
        y_coordinate = 1
        Dim file_length_calculate As Integer = 0
        file_length_calculate = (file_name.Length) * 8
        file_length_calculate = file_length_calculate / 2
        Dim c As Integer = 0
        Dim temp_ascii As String
        temp_ascii = Convert.ToString(file_length_calculate, 2).PadLeft(8, "0")
        For c = 0 To 7 Step 2
            pxl = original.GetPixel(x_coordinate, y_coordinate)
            pxl = encrypt(pxl, temp_ascii(c), temp_ascii(c + 1))
            copied.SetPixel(x_coordinate, y_coordinate, pxl)
            If x_coordinate < original.Width - 1 Then
                x_coordinate = x_coordinate + 1
            Else
                y_coordinate = y_coordinate + 1
                x_coordinate = 0
            End If
        Next
        c = 0
        'encoding file name'
        While c < file_name.Length
            temp_ascii = Nothing
            temp_ascii = Convert.ToString(Asc(file_name(c)), 2).PadLeft(8, "0")
            For i As Integer = 0 To 7 Step 2
                pxl = original.GetPixel(x_coordinate, y_coordinate)
                pxl = encrypt(pxl, temp_ascii(i), temp_ascii(i + 1))
                copied.SetPixel(x_coordinate, y_coordinate, pxl)
                If x_coordinate < original.Width - 1 Then
                    x_coordinate = x_coordinate + 1
                Else
                    y_coordinate = y_coordinate + 1
                    x_coordinate = 0
                End If
            Next
            c = c + 1
        End While

        ' save current x and y position and increment co-ordinates
        Dim temp_x As Integer
        temp_x = x_coordinate
        Dim temp_y As Integer
        temp_y = y_coordinate
        For c = 0 To 3 Step 1
            If x_coordinate < original.Width - 1 Then
                x_coordinate = x_coordinate + 1
            Else
                y_coordinate = y_coordinate + 1
                x_coordinate = 0
            End If
        Next


        ' calculate final message length 
        Dim final_message_length As Integer
        final_message_length = filecontainer.Length


        ' encoding final message length  
        Dim counter As Integer = 0
        While (final_message_length <> 0)
            Dim remainder As Integer
            remainder = final_message_length Mod 10
            temp_ascii = Nothing
            temp_ascii = Convert.ToString(remainder, 2).PadLeft(8, "0")
            For i As Integer = 0 To 7 Step 2
                pxl = original.GetPixel(x_coordinate, y_coordinate)
                pxl = encrypt(pxl, temp_ascii(i), temp_ascii(i + 1))
                copied.SetPixel(x_coordinate, y_coordinate, pxl)
                If x_coordinate < original.Width - 1 Then
                    x_coordinate = x_coordinate + 1
                Else
                    y_coordinate = y_coordinate + 1
                    x_coordinate = 0
                End If
            Next
            final_message_length = (final_message_length - remainder) / 10
            counter = counter + 1
        End While

        ' encode lenght of length at previous blank position 
        counter = counter * 4
        temp_ascii = Convert.ToString(counter, 2).PadLeft(8, "0")
        For c = 0 To 7 Step 2
            pxl = original.GetPixel(temp_x, temp_y)
            pxl = encrypt(pxl, temp_ascii(c), temp_ascii(c + 1))
            copied.SetPixel(temp_x, temp_y, pxl)
            If temp_x < original.Width - 1 Then
                temp_x = temp_x + 1
            Else
                temp_y = temp_y + 1
                temp_x = 0
            End If
        Next


        'encoding file
        final_message_length = filecontainer.Length
        counter = 0
        While counter < final_message_length
            final_msg = Convert.ToString(filecontainer(counter), 2).PadLeft(8, "0")
            For i As Integer = 0 To 7 Step 2
                pxl = original.GetPixel(x_coordinate, y_coordinate)
                pxl = encrypt(pxl, final_msg(i), final_msg(i + 1))
                copied.SetPixel(x_coordinate, y_coordinate, pxl)
                If x_coordinate < original.Width - 1 Then
                    x_coordinate = x_coordinate + 1
                Else
                    y_coordinate = y_coordinate + 1
                    x_coordinate = 0
                End If
            Next
            counter = counter + 1
        End While


        ' set the other blank pixels 
        If x_coordinate < original.Width Then
            While x_coordinate < original.Width
                pxl = original.GetPixel(x_coordinate, y_coordinate)
                copied.SetPixel(x_coordinate, y_coordinate, pxl)
                x_coordinate += 1
            End While
        End If
        If y_coordinate < original.Height Then
            For y_coordinate = y_coordinate + 1 To original.Height - 1 Step 1
                For x_coordinate = 0 To original.Width - 1 Step 1
                    pxl = original.GetPixel(x_coordinate, y_coordinate)
                    copied.SetPixel(x_coordinate, y_coordinate, pxl)
                Next
            Next
        End If
        encodedimage.PictureBox1.Image = copied
        encodedimage.ShowDialog()
        Me.Hide()
        ThankYou.ShowDialog()
    End Sub
    Private Function encrypt(ByVal pxl As Color, ByVal a As String, ByVal b As String) As Color
        Dim alpha As Integer
        Dim ab As String
        ab = Convert.ToString(pxl.A, 2).PadLeft(8, "0")
        ab = String.Concat(ab(0), ab(1), ab(2), ab(3), ab(4), ab(5), a, b)
        alpha = Convert.ToInt32(ab, 2)
        pxl = Color.FromArgb(alpha, pxl.R, pxl.G, pxl.B)
        Return (pxl)
    End Function

     
End Class