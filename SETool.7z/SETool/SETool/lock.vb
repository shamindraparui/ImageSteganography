﻿Public Class lock

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Then
            MsgBox("Please enter password")
        ElseIf TextBox1.Text.Length < 4 Then
            MsgBox("Password must be atleast 4 characters")
        ElseIf TextBox1.Text <> TextBox2.Text Then
            MsgBox("Passwords must be matched")
        Else
            Button1.Enabled = True
            Me.Close()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class