﻿Imports System.IO
Imports System.Drawing.Imaging
Public Class decode
    Public Shared original As Bitmap
    Dim filecontainer() As Byte
    Dim file_name As String

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        OpenFileDialog1.ShowDialog()
        original = Image.FromStream(OpenFileDialog1.OpenFile)
        PictureBox1.Image = original
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim x_coordinate, y_coordinate As Integer
        Dim pxl As Color
        Dim pass_length As Integer
        Dim password As String = Nothing
        x_coordinate = 0
        y_coordinate = 0
        pxl = original.GetPixel(x_coordinate, y_coordinate)
        pass_length = pxl.A
        If x_coordinate < original.Width - 1 Then
            x_coordinate = x_coordinate + 1
        Else
            y_coordinate = y_coordinate + 1
            x_coordinate = 0
        End If
        For i = 0 To pass_length - 1 Step 1
            pxl = original.GetPixel(x_coordinate, y_coordinate)
            Dim pass As Integer = pxl.A
            password = String.Concat(password, Convert.ToChar(pass))
            If x_coordinate < original.Width - 1 Then
                x_coordinate = x_coordinate + 1
            Else
                y_coordinate = y_coordinate + 1
                x_coordinate = 0
            End If
        Next
        Unlock.ShowDialog()
        Dim userpassword As String
        userpassword = Trim(unlock.TextBox1.Text)
        If password <> userpassword Then
            MsgBox(password)
            MsgBox(userpassword)
            Me.Close()
        End If
        x_coordinate = 0
        y_coordinate = 1
        Dim req_pxl As String = Nothing
        Dim c As Integer
        For c = 0 To 7 Step 2
            pxl = original.GetPixel(x_coordinate, y_coordinate)
            req_pxl = decrypt_msg(req_pxl, pxl)

            If x_coordinate < original.Width - 1 Then
                x_coordinate = x_coordinate + 1
            Else
                y_coordinate = y_coordinate + 1
                x_coordinate = 0
            End If
        Next

        Dim required_pixel_to_decrypt_extnsn As Integer
        required_pixel_to_decrypt_extnsn = Convert.ToInt32(req_pxl, 2)



        '***** Decode file name*******

        file_name = Nothing
        Dim temp_file_name As String = Nothing
        c = 0
        For i = 0 To required_pixel_to_decrypt_extnsn - 1 Step 1
            pxl = original.GetPixel(x_coordinate, y_coordinate)
            temp_file_name = decrypt_msg(temp_file_name, pxl)
            c = c + 1
            If x_coordinate < original.Width - 1 Then
                x_coordinate = x_coordinate + 1
            Else
                y_coordinate = y_coordinate + 1
                x_coordinate = 0
            End If
            If c = 4 Then
                Dim temp_ascii As Integer = Convert.ToInt32(temp_file_name, 2)
                Dim each_char As Char = Convert.ToChar(temp_ascii)
                file_name = String.Concat(file_name, each_char)
                c = 0
                temp_file_name = Nothing
            End If

        Next
        Dim temp_bit As String
        temp_bit = Nothing
        For c = 0 To 3 Step 1
            pxl = original.GetPixel(x_coordinate, y_coordinate)
            temp_bit = decrypt_msg(temp_bit, pxl)
            If x_coordinate < original.Width - 1 Then
                x_coordinate = x_coordinate + 1
            Else
                y_coordinate = y_coordinate + 1
                x_coordinate = 0
            End If
        Next

        Dim required_pxl_to_decrypt_length_of_length As Integer

        required_pxl_to_decrypt_length_of_length = Convert.ToInt32(temp_bit, 2)
        Dim data_length As String = Nothing
        Dim msg_length As String = Nothing
        c = 0
        For i As Integer = 0 To required_pxl_to_decrypt_length_of_length - 1 Step 1
            pxl = original.GetPixel(x_coordinate, y_coordinate)
            data_length = decrypt_msg(data_length, pxl)
            c = c + 1
            If x_coordinate < original.Width - 1 Then
                x_coordinate = x_coordinate + 1
            Else
                y_coordinate = y_coordinate + 1
                x_coordinate = 0
            End If
            If c = 4 Then
                Dim temp_length As Integer = Convert.ToInt32(data_length, 2)
                msg_length = String.Concat(msg_length, temp_length)
                c = 0
                data_length = Nothing
            End If
        Next
        msg_length = StrReverse(msg_length)
        Dim temp_msg As String
        temp_msg = Nothing
        Dim counter As Integer
        counter = 0
        filecontainer = New Byte(msg_length) {}
        While counter < msg_length
            temp_msg = Nothing
            For i As Integer = 0 To 7 Step 2
                pxl = original.GetPixel(x_coordinate, y_coordinate)
                temp_msg = decrypt_msg(temp_msg, pxl)
                If x_coordinate < original.Width - 1 Then
                    x_coordinate = x_coordinate + 1
                Else
                    y_coordinate = y_coordinate + 1
                    x_coordinate = 0
                End If
            Next
            filecontainer(counter) = Convert.ToByte(temp_msg, 2)
            counter = counter + 1
        End While
        MsgBox("Successfully Decrypted")
    End Sub
    Private Function decrypt_msg(ByVal temp_msg As String, ByVal pxl As Color) As String
        Dim ch, cd As Char
        Dim ab As String
        ab = Convert.ToString(pxl.A, 2).PadLeft(8, "0")
        ch = ab(6)
        cd = ab(7)
        temp_msg = String.Concat(temp_msg, ch, cd)
        Return (temp_msg)
    End Function

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        SaveFileDialog1.FileName = file_name
        SaveFileDialog1.ShowDialog()
        Dim sp As String = SaveFileDialog1.FileName
        Dim fs As FileStream
        fs = New FileStream(sp, FileMode.Create)
        fs.Write(filecontainer, 0, filecontainer.Length - 1)
        fs.Close()
        Me.Hide()
        ThankYou.ShowDialog()
    End Sub
End Class